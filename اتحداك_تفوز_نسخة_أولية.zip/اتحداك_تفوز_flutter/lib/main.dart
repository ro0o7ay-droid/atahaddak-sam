import 'package:flutter/material.dart';

void main() => runApp(const ChallengeApp());

const navy = Color(0xFF14243A);
const blue = Color(0xFF2364AA);
const gold = Color(0xFFFFC857);
const pale = Color(0xFFF4F7FB);

class ChallengeApp extends StatelessWidget {
  const ChallengeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'اتحداك تفوز',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = [
      ('معلومات عامة', Icons.public, 'اختبر حصيلتك المعرفية'),
      ('علوم', Icons.science, 'اكتشف عالم العلوم'),
      ('رياضة', Icons.sports_soccer, 'كم تعرف عن الرياضة؟'),
      ('تاريخ وثقافة', Icons.account_balance, 'رحلة بين الحضارات'),
      ('ألغاز وذكاء', Icons.psychology_alt, 'شغّل عقلك وفكّر'),
      ('دين', Icons.menu_book, 'أسئلة ثقافية دينية'),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('اتحداك تفوز 🏆', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'ترتيب المتسابقين',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LeaderboardPage())),
            icon: const Icon(Icons.leaderboard_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [navy, blue], begin: Alignment.topRight, end: Alignment.bottomLeft),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('هل أنت مستعد للتحدي؟', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('أجب عن الأسئلة واجمع النقاط وتقدّم في الترتيب.', style: TextStyle(color: Colors.white70, fontSize: 15)),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13)),
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage())),
                    icon: const Icon(Icons.play_arrow_rounded),
                    label: const Text('ابدأ التحدي', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('اختر مجال التحدي', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy)),
                TextButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage())),
                  child: const Text('تحدي اليوم'),
                ),
              ],
            ),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: categories.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.25,
              ),
              itemBuilder: (context, i) {
                final item = categories[i];
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage())),
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE3EAF2))),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(item.$2, color: blue, size: 30),
                        const SizedBox(height: 9),
                        Text(item.$1, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: navy)),
                        const SizedBox(height: 4),
                        Text(item.$3, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 18),
            OutlinedButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LeaderboardPage())),
              icon: const Icon(Icons.emoji_events_outlined),
              label: const Text('عرض ترتيب المتسابقين'),
              style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(14)),
            ),
            const SizedBox(height: 14),
            const Center(child: Text('مساحة إعلانية تجريبية — تُربط بـ AdMob لاحقاً', style: TextStyle(color: Colors.black38, fontSize: 11))),
          ],
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int index = 0;
  int score = 0;
  int? selected;
  bool answered = false;

  final questions = const [
    ('ما عاصمة المملكة العربية السعودية؟', ['جدة', 'الرياض', 'مكة المكرمة', 'الدمام'], 1),
    ('كم عدد أضلاع الشكل السداسي؟', ['خمسة', 'ستة', 'سبعة', 'ثمانية'], 1),
    ('ما الكوكب المعروف بالكوكب الأحمر؟', ['الزهرة', 'المشتري', 'المريخ', 'عطارد'], 2),
    ('ما أكبر محيط في العالم؟', ['الأطلسي', 'الهندي', 'المتجمد الشمالي', 'الهادئ'], 3),
    ('كم عدد أيام السنة الكبيسة؟', ['365', '366', '364', '360'], 1),
  ];

  void choose(int option) {
    if (answered) return;
    setState(() {
      selected = option;
      answered = true;
      if (option == questions[index].$3) score += 10;
    });
  }

  void next() {
    if (index == questions.length - 1) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ResultPage(score: score, total: questions.length * 10)));
    } else {
      setState(() { index++; selected = null; answered = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = questions[index];
    return Scaffold(
      appBar: AppBar(title: const Text('التحدي')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LinearProgressIndicator(value: (index + 1) / questions.length, minHeight: 8, borderRadius: BorderRadius.circular(20)),
            const SizedBox(height: 12),
            Text('السؤال ${index + 1} من ${questions.length}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 28),
            Text(q.$1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: navy)),
            const SizedBox(height: 24),
            ...List.generate(q.$2.length, (i) {
              final isCorrect = i == q.$3;
              final isSelected = selected == i;
              Color bg = Colors.white;
              Color border = const Color(0xFFE0E7EF);
              if (answered && isCorrect) { bg = const Color(0xFFE2F6E9); border = Colors.green; }
              else if (answered && isSelected) { bg = const Color(0xFFFFE8E8); border = Colors.red; }
              return Padding(
                padding: const EdgeInsets.only(bottom: 11),
                child: InkWell(
                  onTap: () => choose(i),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14), border: Border.all(color: border, width: 1.3)),
                    child: Text(q.$2[i], textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                  ),
                ),
              );
            }),
            const Spacer(),
            if (answered)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(selected == q.$3 ? 'إجابة صحيحة! +10 نقاط 🎉' : 'ليست الإجابة الصحيحة، حاول في السؤال القادم.', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, color: selected == q.$3 ? Colors.green : Colors.red)),
              ),
            FilledButton(
              onPressed: answered ? next : null,
              style: FilledButton.styleFrom(backgroundColor: blue, padding: const EdgeInsets.all(15)),
              child: Text(index == questions.length - 1 ? 'إنهاء التحدي' : 'السؤال التالي'),
            ),
          ],
        ),
      ),
    );
  }
}

class ResultPage extends StatelessWidget {
  final int score;
  final int total;
  const ResultPage({super.key, required this.score, required this.total});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('نتيجتك')),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.emoji_events, color: gold, size: 82),
          const SizedBox(height: 14),
          const Text('أحسنت! انتهى التحدي', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 12),
          Text('$score من $total نقطة', style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: blue)),
          const SizedBox(height: 26),
          FilledButton(onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomePage()), (_) => false), child: const Text('العودة للرئيسية')),
        ]),
      ),
    ),
  );
}

class LeaderboardPage extends StatelessWidget {
  const LeaderboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    final names = ['المتحدي الذهبي', 'صقر المعرفة', 'عبقري التحدي', 'نجم المسابقات', 'بطل المعلومات'];
    return Scaffold(
      appBar: AppBar(title: const Text('ترتيب المتسابقين')),
      body: ListView.separated(
        padding: const EdgeInsets.all(18),
        itemCount: names.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) => Card(
          child: ListTile(
            leading: CircleAvatar(backgroundColor: i == 0 ? gold : const Color(0xFFE7EEF7), child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold, color: navy))),
            title: Text(names[i], style: const TextStyle(fontWeight: FontWeight.bold)),
            trailing: Text('${500 - i * 65} نقطة', style: const TextStyle(color: blue, fontWeight: FontWeight.bold)),
          ),
        ),
      ),
    );
  }
}
